#!/usr/bin/env python3
"""plato-midi-bridge — PLATO rooms as MIDI instruments."""
from setuptools import find_packages, setup

setup(
    name="plato-midi-bridge",
    version="0.1.0",
    description="PLATO rooms as MIDI instruments — coupling matrix becomes harmony, t-minus events become tension",
    author="SuperInstance",
    packages=find_packages(),
    install_requires=["numpy"],
    extras_require={
        "torch": ["torch>=2.0.0"],
    },
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "plato-midi-bridge=plato_midi_bridge.cli:main",
        ],
    },
)
