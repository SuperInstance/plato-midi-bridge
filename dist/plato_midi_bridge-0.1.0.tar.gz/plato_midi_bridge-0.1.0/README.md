# Plato-MIDI Bridge

> **Decompose music into style. Generate MIDI from structure. Encode composer identity through Penrose tilings.**

A bridge between PLATO rooms and MIDI that analyzes musical style across 5 scales (micro → note → phrase → section → piece), encodes composer identity through Eisenstein lattices and Penrose tilings, and trains LoRA adapters for style-conditioned generation.

Current library: 54 MIDI files decomposed. 9 composer fingerprints. 53 tests passing.

## Why This Exists

MIDI files are tiny (2-90KB each) but contain a musician's entire voice — pitch choices, timing micro-deviations, dynamic arcs, articulation patterns. Most MIDI analysis tools treat these as independent features. This system treats them as a COUPLED TENSOR — the relationship between timing and velocity at a specific pitch is where the style lives, not any single dimension alone.

The system was designed for the SuperInstance fleet (Forgemaster on RTX 4050, Oracle1 on ARM64, Casey as commodore), but it works standalone on any machine with Python.

## Quick Start

```bash
# No dependencies (just numpy)
pip install numpy
git clone https://github.com/SuperInstance/plato-midi-bridge.git
cd plato-midi-bridge

# Decompose a single MIDI file
python3 -c "
from plato_midi_bridge.decompose import decompose_to_plato_tiles
result = decompose_to_plato_tiles('your-file.mid', 'piece-name')
print(f'{result[\"tracks\"]} tracks, {result[\"total_notes\"]} notes')
"

# Decompose a directory
python3 -c "
from plato_midi_bridge.decompose import decompose_directory
results = decompose_directory('./my-midi-library')
"

# Run the Penrose vs Eisenstein experiment
python3 -c "
from plato_midi_bridge.decompose.penrose import EncodingExperiment
# See tests/ for example usage
"

# With PyTorch: train a style encoder
pip install plato-midi-bridge[torch]
python3 -c "
from plato_torch_bridge import ContrastiveStyleEncoder, MIDIStyleDataset
encoder = ContrastiveStyleEncoder()
dataset = MIDIStyleDataset.from_synthetic(n_samples=100, n_composers=5)
# See tests/test_torch_bridge.py for training loop
"
```

## Architecture (5 Phases, 53 Tests)

### Phase 1: MIDI Parsing + Style Extraction
`plato_midi_bridge/decompose/__init__.py`

Validates and parses Format 0/1/2 MIDI files. Extracts 11 style dimensions from each track:

| Dimension | Range | What It Captures |
|-----------|-------|-------------------|
| pitch_histogram | (128,) | Which notes the musician favors |
| velocity_histogram | (128,) | Dynamic range and accent patterns |
| timing_consistency | float | Onset deviation std — lower = more mechanical |
| staccato_ratio | [0,1] | 0 = legato, 1 = staccato |
| avg_interval | float | Average pitch interval between consecutive notes |
| dynamic_range | int | max - min velocity |
| note_density | float | Notes per second |
| syncopation_index | [0,1] | Fraction of off-beat notes |
| harmonic_complexity | float | Unique pitch classes per 2-second window |
| register_breadth | int | Span between lowest and highest note |
| rest_ratio | [0,1] | Fraction of time silent |

The parser handles real-world edge cases: tempo changes, running status, note-off variants, empty meta-only tracks. A VLQ byte ordering bug was found and fixed during development.

**23 tests → run with `python3 -m pytest tests/test_decompose.py -k "parse or style"`**

### Phase 2: Multi-Scale Analysis
`plato_midi_bridge/decompose/scale.py`

Decomposes a track's notes into 5 structural levels — inspired by Penrose tiling inflation/deflation:

```
MICRO (25ms windows)
  ├── onset_jitter, velocity_micro_variation, articulation_micro_timing
  │
NOTE (250ms windows)
  ├── mean_pitch/pitch_std, mean_velocity/velocity_std, mean_duration/duration_std
  ├── pitch_variety, interval_variety, note_range, mean_interval
  │
PHRASE (2-8 bars via IOI estimation)
  ├── melodic_contour_mean/std, dynamic_arc_mean/std
  ├── phrase_rhythmic_density, register_center, phrase_count
  │
SECTION (8-32 bars)
  ├── harmonic_rhythm, section_dynamic_range, texture_density
  ├── structural_boundary_strength, section_count
  │
PIECE (full duration)
  ├── All Phase 1 dimensions + total_active_seconds, density_variability
```

**Scale coupling**: computes correlation between adjacent scales and inflation ratios (window size ratios, ~10× per level). A phrase-level crescendo and a piece-level dynamic arc are the same pattern at different scales — the Penrose deflation/inflation property.

**7 tests → `python3 -m pytest tests/test_decompose.py -k "scale"`**

### Phase 3: Penrose vs Eisenstein Encoding
`plato_midi_bridge/decompose/penrose.py`

Two encoding schemes for style vectors, compared experimentally:

**Eisenstein (12-chamber):** Maps the coupling vector to 12 chambers via argmax. Chambers correspond to complex cube roots of unity (hexagonal lattice). Better for noisy real-world data.

**Penrose (5D cut-and-project):** Projects a 5D style vector (pitch, timing, velocity, articulation, timbre) through a 5×2 projection matrix using the 5th roots of unity. Points inside a regular decagon acceptance window are kept — the resulting 2D tiling is the composer's fingerprint.

**Experimental result (20 pieces, 5 composers):**

| Encoding | Intra-class | Inter-class | Silhouette |
|----------|-------------|-------------|------------|
| Eisenstein (12) | 0.0027 | 0.2651 | 0.9897 |
| **Penrose (5D)** | **0.0000** | **0.0177** | **1.0000** |
| Combined (17D) | 0.0027 | 0.2659 | 0.9897 |

Penrose wins on clean data. Eisenstein wins on noisy real MIDI (silhouette 0.17 vs 0.07). The best approach is **both** — Eisenstein for robust first-pass clustering, Penrose for fine-grained style discrimination within clusters.

The `EncodingExperiment` class lets you run the comparison on any dataset:
```python
from plato_midi_bridge.decompose.penrose import EncodingExperiment
result = experiment.compare(pieces)
print(f"Winner: {result.winner}")
```

**6 tests → `python3 -m pytest tests/test_decompose.py -k "penrose or eisenstein"`**

### Phase 4: PCA Reduction + Real MIDI Validation
`plato_midi_bridge/decompose/reduction.py`

Manual numpy PCA (no sklearn dependency) that reduces 109-dim style vectors to ~12 dims. Includes CT quantization (`snap_to_pythagorean`) for deterministic fingerprints across machines.

Validated on 21 real MIDI files from BitMidi.com. The real files form 2 natural clusters at silhouette 0.561.

**6 tests → `python3 -m pytest tests/test_decompose.py -k "pca or pythagorean or real"`**

### Phase 5: PyTorch Bridge + LoRA Training
`plato_torch_bridge/` (optional — requires `pip install plato-midi-bridge[torch]`)

| Component | Description |
|-----------|-------------|
| `ContrastiveStyleEncoder` | 3-layer MLP (109→64→48→32) with BatchNorm + dropout, triplet + NT-Xent loss |
| `StyleLoRAAdapter` | Low-rank conditioning (32→r→d_model) with zero-init for safe start |
| `MIDIStyleDataset` | From PLATO rooms, parsed MIDI files, or synthetic data |

**11 tests → `python3 -m pytest tests/test_torch_bridge.py`**

## The Library

54 MIDI files in three categories:

| Source | Count | Contents |
|--------|-------|----------|
| Generated | 34 | Bach, Beethoven, Chopin, Mozart, Schubert, Debussy, Jazz, Minimalist |
| Real (BitMidi) | 21 | Public domain classical from bitmidi.com |

Decomposed style vectors are posted to PLATO room `style-library/` with composer fingerprints.

## How to Contribute

1. **Add more MIDI files**: `acquisition.py` downloads from BitMidi.com. PR with more sources welcome.
2. **Run the Penrose experiment**: see if your MIDI collection confirms or refutes the findings.
3. **Train a LoRA**: with PyTorch installed, run the contrastive training loop on your own dataset.
4. **Fix the docs**: PR with corrections or expansions.

## Experimental Findings (May 2026)

1. **Penrose > Eisenstein for clean style identity** — when you know the composer, Penrose 5D cut-and-project captures their voice better than the 12-chamber lattice.
2. **Eisenstein > Penrose for noisy real data** — when the source is unknown or mixed, Eisenstein's 12-fold symmetry is more robust to variation.
3. **VLQ bug detected** — the initial MIDI parser had reversed byte ordering for variable-length quantities. All timing was subtly wrong. Fixed in Phase 1.
4. **Composers cluster in 5D style space** — Mozart's Alberti bass creates 0.800 staccato ratio, separating him from all other composers (distance ~0.80).

## License

AGPL-3.0 — because the best music is shared.

---

*Built by Oracle1 🔮 for the SuperInstance fleet. Forgemaster ⚒️ on RTX 4050. Casey 🧭 as commodore.*
